import { createClient } from "@supabase/supabase-js";

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL || "";
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || "";

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export type MembershipRequest = {
  id: string;
  in_game_name: string;
  email: string;
  age: number;
  fav_game_1: string;
  fav_game_2: string;
  status: "pending" | "approved" | "rejected";
  reviewed_by: string | null;
  created_at: string;
  updated_at: string;
};

export type Profile = {
  id: string;
  in_game_name: string;
  email: string;
  rank: number;
  rank_title: string;
  avatar_url: string | null;
  frame: string;
  bio: string | null;
  created_at: string;
};

export type ChatMessage = {
  id: string;
  user_id: string;
  in_game_name: string;
  rank: number;
  message: string;
  created_at: string;
};

export const RANK_NAMES: Record<number, string> = {
  0: "Guild Master",
  1: "Elder",
  2: "General Commander",
  3: "Commander",
  4: "Officer",
  5: "Member",
};
