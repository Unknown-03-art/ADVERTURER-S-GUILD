"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { supabase, Profile } from "@/lib/supabase";
import Link from "next/link";

type Gift = {
  id: string;
  sender_id: string;
  receiver_id: string;
  gift_type: "coupon" | "money";
  title: string;
  description: string | null;
  amount_cents: number;
  coupon_code: string | null;
  status: string;
  created_at: string;
  claimed_at: string | null;
  sender?: { in_game_name: string };
  receiver?: { in_game_name: string };
};

export default function GiftsPage() {
  const router = useRouter();
  const [profile, setProfile] = useState<Profile | null>(null);
  const [gifts, setGifts] = useState<Gift[]>([]);
  const [members, setMembers] = useState<{ id: string; in_game_name: string }[]>([]);
  const [loading, setLoading] = useState(true);
  const [showSend, setShowSend] = useState(false);
  const [message, setMessage] = useState("");

  // Form state
  const [receiverId, setReceiverId] = useState("");
  const [giftType, setGiftType] = useState<"coupon" | "money">("coupon");
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [amount, setAmount] = useState("");
  const [couponCode, setCouponCode] = useState("");

  useEffect(() => {
    const load = async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        router.push("/login");
        return;
      }

      const { data: profileData } = await supabase
        .from("profiles")
        .select("*")
        .eq("id", user.id)
        .single();

      if (!profileData) {
        router.push("/login");
        return;
      }
      setProfile(profileData);

      // Load gifts (sent + received)
      const { data: giftsData } = await supabase
        .from("gifts")
        .select(`
          *,
          sender:profiles!gifts_sender_id_fkey(in_game_name),
          receiver:profiles!gifts_receiver_id_fkey(in_game_name)
        `)
        .or(`sender_id.eq.${user.id},receiver_id.eq.${user.id}`)
        .order("created_at", { ascending: false });

      setGifts(giftsData || []);

      // Load all members for the send dropdown
      const { data: membersData } = await supabase
        .from("profiles")
        .select("id, in_game_name")
        .neq("id", user.id)
        .order("in_game_name");

      setMembers(membersData || []);
      setLoading(false);
    };
    load();
  }, [router]);

  const handleSendGift = async () => {
    if (!profile || !receiverId || !title.trim()) {
      setMessage("Please fill in the required fields.");
      return;
    }

    if (giftType === "money" && (!amount || parseFloat(amount) <= 0)) {
      setMessage("Please enter a valid amount for money gifts.");
      return;
    }

    if (giftType === "coupon" && !couponCode.trim()) {
      setMessage("Please enter a coupon code.");
      return;
    }

    const amountCents = giftType === "money" ? Math.round(parseFloat(amount) * 100) : 0;

    const { error } = await supabase.from("gifts").insert({
      sender_id: profile.id,
      receiver_id: receiverId,
      gift_type: giftType,
      title: title.trim(),
      description: description.trim() || null,
      amount_cents: amountCents,
      coupon_code: giftType === "coupon" ? couponCode.trim() : null,
      status: "pending",
    });

    if (error) {
      console.error(error);
      setMessage("Failed to send gift. Please try again.");
      return;
    }

    if (giftType === "money") {
      setMessage(
        `Gift recorded! Please send $${amount} via PayPal to the receiver (or to the Guild Master if preferred) and mark it as sent once paid. The receiver will see the gift in their list.`
      );
    } else {
      setMessage("Coupon gift sent successfully!");
    }

    // Reset form
    setShowSend(false);
    setReceiverId("");
    setTitle("");
    setDescription("");
    setAmount("");
    setCouponCode("");
    setGiftType("coupon");

    // Refresh list
    const { data: giftsData } = await supabase
      .from("gifts")
      .select(`
        *,
        sender:profiles!gifts_sender_id_fkey(in_game_name),
        receiver:profiles!gifts_receiver_id_fkey(in_game_name)
      `)
      .or(`sender_id.eq.${profile.id},receiver_id.eq.${profile.id}`)
      .order("created_at", { ascending: false });

    setGifts(giftsData || []);
  };

  const handleClaim = async (giftId: string) => {
    const { error } = await supabase
      .from("gifts")
      .update({ status: "claimed", claimed_at: new Date().toISOString() })
      .eq("id", giftId);

    if (!error) {
      setGifts((prev) =>
        prev.map((g) => (g.id === giftId ? { ...g, status: "claimed" } : g))
      );
      setMessage("Gift claimed!");
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#0a0a0a] text-gray-400">
        Loading gifts...
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0a0a0a] text-gray-100 px-4 py-8">
      <div className="max-w-3xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <h1 className="text-2xl font-bold text-[#d4af37]">Gifts</h1>
          <Link href="/dashboard" className="text-sm text-gray-400 hover:text-white">
            Dashboard
          </Link>
        </div>

        {message && (
          <div className="mb-6 p-4 rounded-lg bg-[#1a1a1a] border border-[#d4af37]/30 text-sm text-[#d4af37]">
            {message}
          </div>
        )}

        {/* Send Gift Button */}
        {!showSend ? (
          <button
            onClick={() => setShowSend(true)}
            className="mb-8 px-6 py-3 rounded-lg font-semibold text-black bg-gradient-to-r from-[#d4af37] to-[#b8960c] hover:from-[#e0c040] hover:to-[#c9a70e] transition"
          >
            Send a Gift
          </button>
        ) : (
          <div className="mb-8 bg-[#141414] border border-[#2a2a2a] rounded-xl p-6 space-y-4">
            <h2 className="text-lg font-semibold text-white">Send a Gift</h2>

            <div>
              <label className="block text-sm text-gray-300 mb-1">To (member)</label>
              <select
                value={receiverId}
                onChange={(e) => setReceiverId(e.target.value)}
                className="w-full px-4 py-3 rounded-lg bg-[#0a0a0a] border border-[#333] text-white focus:outline-none focus:border-[#d4af37]"
              >
                <option value="">Select member...</option>
                {members.map((m) => (
                  <option key={m.id} value={m.id}>
                    {m.in_game_name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm text-gray-300 mb-1">Gift Type</label>
              <div className="flex gap-4">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="radio"
                    checked={giftType === "coupon"}
                    onChange={() => setGiftType("coupon")}
                  />
                  <span>In-game Coupon</span>
                </label>
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="radio"
                    checked={giftType === "money"}
                    onChange={() => setGiftType("money")}
                  />
                  <span>Real Money (PayPal)</span>
                </label>
              </div>
            </div>

            <div>
              <label className="block text-sm text-gray-300 mb-1">Title</label>
              <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder={giftType === "coupon" ? "e.g. 1000 Gold Coupon" : "e.g. Birthday gift"}
                className="w-full px-4 py-3 rounded-lg bg-[#0a0a0a] border border-[#333] text-white focus:outline-none focus:border-[#d4af37]"
              />
            </div>

            {giftType === "coupon" && (
              <div>
                <label className="block text-sm text-gray-300 mb-1">Coupon Code</label>
                <input
                  type="text"
                  value={couponCode}
                  onChange={(e) => setCouponCode(e.target.value)}
                  placeholder="The actual code the player can redeem in-game"
                  className="w-full px-4 py-3 rounded-lg bg-[#0a0a0a] border border-[#333] text-white focus:outline-none focus:border-[#d4af37]"
                />
              </div>
            )}

            {giftType === "money" && (
              <div>
                <label className="block text-sm text-gray-300 mb-1">Amount (USD)</label>
                <input
                  type="number"
                  min="0.01"
                  step="0.01"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  placeholder="5.00"
                  className="w-full px-4 py-3 rounded-lg bg-[#0a0a0a] border border-[#333] text-white focus:outline-none focus:border-[#d4af37]"
                />
              </div>
            )}

            <div>
              <label className="block text-sm text-gray-300 mb-1">Message (optional)</label>
              <textarea
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                rows={2}
                placeholder="Add a personal note..."
                className="w-full px-4 py-3 rounded-lg bg-[#0a0a0a] border border-[#333] text-white focus:outline-none focus:border-[#d4af37]"
              />
            </div>

            <div className="flex gap-3">
              <button
                onClick={handleSendGift}
                className="px-5 py-2.5 rounded-lg font-medium text-black bg-gradient-to-r from-[#d4af37] to-[#b8960c]"
              >
                Send Gift
              </button>
              <button
                onClick={() => setShowSend(false)}
                className="px-5 py-2.5 rounded-lg text-gray-400 border border-[#333]"
              >
                Cancel
              </button>
            </div>
          </div>
        )}

        {/* Gift List */}
        <h2 className="text-lg font-semibold mb-4 text-white">Your Gifts</h2>

        {gifts.length === 0 ? (
          <p className="text-gray-500">No gifts yet. Send the first one!</p>
        ) : (
          <div className="space-y-3">
            {gifts.map((gift) => {
              const isReceiver = gift.receiver_id === profile?.id;
              const isSender = gift.sender_id === profile?.id;

              return (
                <div
                  key={gift.id}
                  className="bg-[#141414] border border-[#2a2a2a] rounded-xl p-5"
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <span className="font-semibold text-white">{gift.title}</span>
                        <span
                          className={`text-xs px-2 py-0.5 rounded ${
                            gift.gift_type === "money"
                              ? "bg-green-900/40 text-green-400"
                              : "bg-purple-900/40 text-purple-300"
                          }`}
                        >
                          {gift.gift_type === "money" ? "Money" : "Coupon"}
                        </span>
                        <span className="text-xs text-gray-500 capitalize">{gift.status}</span>
                      </div>

                      <p className="text-sm text-gray-400">
                        {isSender ? (
                          <>To: <span className="text-white">{gift.receiver?.in_game_name}</span></>
                        ) : (
                          <>From: <span className="text-white">{gift.sender?.in_game_name}</span></>
                        )}
                      </p>

                      {gift.description && (
                        <p className="text-sm text-gray-500 mt-1">{gift.description}</p>
                      )}

                      {gift.gift_type === "money" && (
                        <p className="text-sm text-[#d4af37] mt-1">
                          ${(gift.amount_cents / 100).toFixed(2)} USD
                        </p>
                      )}

                      {gift.gift_type === "coupon" && gift.coupon_code && isReceiver && gift.status !== "pending" && (
                        <p className="text-sm text-purple-300 mt-1 font-mono">
                          Code: {gift.coupon_code}
                        </p>
                      )}
                    </div>

                    <div className="flex gap-2">
                      {isReceiver && gift.status === "pending" && (
                        <button
                          onClick={() => handleClaim(gift.id)}
                          className="px-4 py-2 rounded-lg text-sm font-medium bg-green-800 hover:bg-green-700 text-white transition"
                        >
                          Claim
                        </button>
                      )}
                      {isSender && gift.gift_type === "money" && gift.status === "pending" && (
                        <span className="text-xs text-gray-500 self-center">
                          Send PayPal payment then ask receiver to claim
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        <p className="mt-8 text-xs text-gray-600 text-center">
          Money gifts: Send the amount via PayPal to the receiver (or Guild Master).  
          After payment is confirmed, the receiver can claim the gift.
        </p>
      </div>
    </div>
  );
}
