"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { supabase, Profile } from "@/lib/supabase";
import Link from "next/link";

type Rating = {
  id: string;
  user_id: string;
  game_name: string;
  rating: number;
  review: string | null;
  created_at: string;
  profiles?: { in_game_name: string };
};

type Average = {
  game_name: string;
  avg_rating: number;
  count: number;
};

export default function RatingsPage() {
  const router = useRouter();
  const [profile, setProfile] = useState<Profile | null>(null);
  const [averages, setAverages] = useState<Average[]>([]);
  const [myRatings, setMyRatings] = useState<Rating[]>([]);
  const [loading, setLoading] = useState(true);
  const [gameName, setGameName] = useState("");
  const [rating, setRating] = useState(80);
  const [review, setReview] = useState("");
  const [message, setMessage] = useState("");

  useEffect(() => {
    const load = async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        router.push("/login");
        return;
      }
      const { data: profileData } = await supabase.from("profiles").select("*").eq("id", user.id).single();
      if (!profileData) {
        router.push("/login");
        return;
      }
      setProfile(profileData);

      // Load averages
      const { data: allRatings } = await supabase.from("game_ratings").select("game_name, rating");
      if (allRatings) {
        const map = new Map<string, { total: number; count: number }>();
        allRatings.forEach((r) => {
          const cur = map.get(r.game_name) || { total: 0, count: 0 };
          cur.total += r.rating;
          cur.count += 1;
          map.set(r.game_name, cur);
        });
        const avgs: Average[] = [];
        map.forEach((v, k) => {
          avgs.push({ game_name: k, avg_rating: Math.round(v.total / v.count), count: v.count });
        });
        avgs.sort((a, b) => b.avg_rating - a.avg_rating);
        setAverages(avgs);
      }

      // My ratings
      const { data: mine } = await supabase
        .from("game_ratings")
        .select("*")
        .eq("user_id", user.id)
        .order("created_at", { ascending: false });
      setMyRatings(mine || []);
      setLoading(false);
    };
    load();
  }, [router]);

  const handleSubmit = async () => {
    if (!profile || !gameName.trim()) {
      setMessage("Please enter a game name.");
      return;
    }
    if (rating < 1 || rating > 100) {
      setMessage("Rating must be between 1 and 100.");
      return;
    }

    const { error } = await supabase.from("game_ratings").upsert({
      user_id: profile.id,
      game_name: gameName.trim(),
      rating,
      review: review.trim() || null,
    }, { onConflict: "user_id,game_name" });

    if (error) {
      setMessage("Failed to save rating.");
      return;
    }

    setMessage("Rating saved!");
    setGameName("");
    setReview("");
    setRating(80);

    // Refresh
    const { data: mine } = await supabase
      .from("game_ratings")
      .select("*")
      .eq("user_id", profile.id)
      .order("created_at", { ascending: false });
    setMyRatings(mine || []);
  };

  if (loading) {
    return <div className="min-h-screen flex items-center justify-center bg-[#0a0a0a] text-gray-400">Loading ratings...</div>;
  }

  return (
    <div className="min-h-screen bg-[#0a0a0a] text-gray-100 px-4 py-8">
      <div className="max-w-3xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <h1 className="text-2xl font-bold text-[#d4af37]">Game Ratings</h1>
          <Link href="/dashboard" className="text-sm text-gray-400 hover:text-white">Dashboard</Link>
        </div>

        {message && (
          <div className="mb-6 p-4 rounded-lg bg-[#1a1a1a] border border-[#d4af37]/30 text-sm text-[#d4af37]">{message}</div>
        )}

        {/* Rate a game */}
        <div className="bg-[#141414] border border-[#2a2a2a] rounded-xl p-6 mb-8 space-y-4">
          <h2 className="text-lg font-semibold text-white">Rate a Game (1–100)</h2>
          <input
            type="text"
            value={gameName}
            onChange={(e) => setGameName(e.target.value)}
            placeholder="Game name"
            className="w-full px-4 py-3 rounded-lg bg-[#0a0a0a] border border-[#333] text-white focus:outline-none focus:border-[#d4af37]"
          />
          <div>
            <label className="block text-sm text-gray-300 mb-1">Your rating: {rating}</label>
            <input
              type="range"
              min="1"
              max="100"
              value={rating}
              onChange={(e) => setRating(parseInt(e.target.value))}
              className="w-full"
            />
          </div>
          <textarea
            value={review}
            onChange={(e) => setReview(e.target.value)}
            placeholder="Optional short review"
            rows={2}
            className="w-full px-4 py-3 rounded-lg bg-[#0a0a0a] border border-[#333] text-white focus:outline-none focus:border-[#d4af37]"
          />
          <button
            onClick={handleSubmit}
            className="px-6 py-2.5 rounded-lg font-semibold text-black bg-gradient-to-r from-[#d4af37] to-[#b8960c]"
          >
            Submit Rating
          </button>
        </div>

        {/* Top rated games */}
        <h2 className="text-lg font-semibold text-white mb-4">Top Rated Games</h2>
        {averages.length === 0 ? (
          <p className="text-gray-500 mb-8">No ratings yet.</p>
        ) : (
          <div className="space-y-2 mb-8">
            {averages.map((a) => (
              <div key={a.game_name} className="bg-[#141414] border border-[#2a2a2a] rounded-lg px-4 py-3 flex justify-between items-center">
                <span className="font-medium text-white">{a.game_name}</span>
                <div className="text-right">
                  <span className="text-[#d4af37] font-bold">{a.avg_rating}/100</span>
                  <span className="text-xs text-gray-500 ml-2">({a.count} ratings)</span>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* My ratings */}
        <h2 className="text-lg font-semibold text-white mb-4">My Ratings</h2>
        {myRatings.length === 0 ? (
          <p className="text-gray-500">You haven’t rated any games yet.</p>
        ) : (
          <div className="space-y-2">
            {myRatings.map((r) => (
              <div key={r.id} className="bg-[#141414] border border-[#2a2a2a] rounded-lg px-4 py-3">
                <div className="flex justify-between">
                  <span className="font-medium text-white">{r.game_name}</span>
                  <span className="text-[#d4af37] font-bold">{r.rating}/100</span>
                </div>
                {r.review && <p className="text-sm text-gray-400 mt-1">{r.review}</p>}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
