"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { supabase, Profile } from "@/lib/supabase";
import Link from "next/link";

type Clan = {
  id: string;
  name: string;
  description: string | null;
  leader_id: string;
  level: number;
  member_count: number;
  contribution_points: number;
  created_at: string;
};

export default function ClansPage() {
  const router = useRouter();
  const [profile, setProfile] = useState<Profile | null>(null);
  const [clans, setClans] = useState<Clan[]>([]);
  const [loading, setLoading] = useState(true);
  const [showCreate, setShowCreate] = useState(false);
  const [clanName, setClanName] = useState("");
  const [clanDesc, setClanDesc] = useState("");
  const [message, setMessage] = useState("");
  const [myClanId, setMyClanId] = useState<string | null>(null);

  useEffect(() => {
    const load = async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        router.push("/login");
        return;
      }
      const { data: profileData } = await supabase.from("profiles").select("*").eq("id", user.id).single();
      if (!profileData) {
        router.push("/login");
        return;
      }
      setProfile(profileData);

      // Check if user is already in a clan
      const { data: membership } = await supabase
        .from("clan_members")
        .select("clan_id")
        .eq("user_id", user.id)
        .maybeSingle();
      if (membership) setMyClanId(membership.clan_id);

      const { data: clansData } = await supabase
        .from("clans")
        .select("*")
        .order("level", { ascending: false });
      setClans(clansData || []);
      setLoading(false);
    };
    load();
  }, [router]);

  const handleCreateClan = async () => {
    if (!profile || !clanName.trim()) return;
    setMessage("");

    // Record the $5 purchase as pending
    await supabase.from("purchases").insert({
      user_id: profile.id,
      item_type: "clan_creation",
      item_id: clanName.trim(),
      amount_cents: 500,
      payment_provider: "paypal",
      status: "pending",
    });

    // Create the clan (in real life we would wait for payment confirmation)
    const { data: newClan, error } = await supabase
      .from("clans")
      .insert({
        name: clanName.trim(),
        description: clanDesc.trim() || null,
        leader_id: profile.id,
        level: 1,
        member_count: 1,
      })
      .select()
      .single();

    if (error) {
      setMessage("Could not create clan. Name may already be taken.");
      return;
    }

    // Add leader as member
    await supabase.from("clan_members").insert({
      clan_id: newClan.id,
      user_id: profile.id,
      role: "leader",
    });

    setMessage(
      `Clan "${clanName}" created! Please send $5 via PayPal to the Guild Master to complete the purchase. After confirmation the clan becomes fully active.`
    );
    setShowCreate(false);
    setClanName("");
    setClanDesc("");
    setMyClanId(newClan.id);
    setClans((prev) => [newClan, ...prev]);
  };

  const handleJoin = async (clanId: string) => {
    if (!profile || myClanId) return;

    const clan = clans.find((c) => c.id === clanId);
    if (!clan || clan.member_count >= 25) {
      setMessage("This clan is full (max 25 members).");
      return;
    }

    const { error } = await supabase.from("clan_members").insert({
      clan_id: clanId,
      user_id: profile.id,
      role: "member",
    });

    if (error) {
      setMessage("Could not join clan.");
      return;
    }

    // Update member count
    await supabase
      .from("clans")
      .update({ member_count: clan.member_count + 1 })
      .eq("id", clanId);

    setMyClanId(clanId);
    setMessage("You joined the clan!");
    setClans((prev) =>
      prev.map((c) => (c.id === clanId ? { ...c, member_count: c.member_count + 1 } : c))
    );
  };

  if (loading) {
    return <div className="min-h-screen flex items-center justify-center bg-[#0a0a0a] text-gray-400">Loading clans...</div>;
  }

  return (
    <div className="min-h-screen bg-[#0a0a0a] text-gray-100 px-4 py-8">
      <div className="max-w-3xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <h1 className="text-2xl font-bold text-[#d4af37]">Clans</h1>
          <Link href="/dashboard" className="text-sm text-gray-400 hover:text-white">Dashboard</Link>
        </div>

        {message && (
          <div className="mb-6 p-4 rounded-lg bg-[#1a1a1a] border border-[#d4af37]/30 text-sm text-[#d4af37]">
            {message}
          </div>
        )}

        {!myClanId && (
          <div className="mb-8">
            {!showCreate ? (
              <button
                onClick={() => setShowCreate(true)}
                className="px-6 py-3 rounded-lg font-semibold text-black bg-gradient-to-r from-[#d4af37] to-[#b8960c] hover:from-[#e0c040] hover:to-[#c9a70e] transition"
              >
                Create a Clan ($5)
              </button>
            ) : (
              <div className="bg-[#141414] border border-[#2a2a2a] rounded-xl p-6 space-y-4">
                <h2 className="text-lg font-semibold text-white">Create New Clan</h2>
                <input
                  type="text"
                  value={clanName}
                  onChange={(e) => setClanName(e.target.value)}
                  placeholder="Clan name"
                  className="w-full px-4 py-3 rounded-lg bg-[#0a0a0a] border border-[#333] text-white focus:outline-none focus:border-[#d4af37]"
                />
                <textarea
                  value={clanDesc}
                  onChange={(e) => setClanDesc(e.target.value)}
                  placeholder="Short description (optional)"
                  rows={2}
                  className="w-full px-4 py-3 rounded-lg bg-[#0a0a0a] border border-[#333] text-white focus:outline-none focus:border-[#d4af37]"
                />
                <div className="flex gap-3">
                  <button
                    onClick={handleCreateClan}
                    className="px-5 py-2.5 rounded-lg font-medium text-black bg-gradient-to-r from-[#d4af37] to-[#b8960c]"
                  >
                    Create & Pay $5
                  </button>
                  <button
                    onClick={() => setShowCreate(false)}
                    className="px-5 py-2.5 rounded-lg text-gray-400 border border-[#333]"
                  >
                    Cancel
                  </button>
                </div>
              </div>
            )}
          </div>
        )}

        <h2 className="text-lg font-semibold mb-4 text-white">All Clans</h2>
        {clans.length === 0 ? (
          <p className="text-gray-500">No clans yet. Be the first to create one!</p>
        ) : (
          <div className="space-y-3">
            {clans.map((clan) => (
              <div key={clan.id} className="bg-[#141414] border border-[#2a2a2a] rounded-xl p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="font-semibold text-white text-lg">{clan.name}</h3>
                    <span className="text-xs px-2 py-0.5 rounded bg-[#d4af37]/20 text-[#d4af37]">
                      Level {clan.level}
                    </span>
                  </div>
                  {clan.description && <p className="text-sm text-gray-400 mt-1">{clan.description}</p>}
                  <p className="text-xs text-gray-500 mt-1">
                    {clan.member_count}/25 members • {clan.contribution_points} contribution
                  </p>
                </div>
                <div>
                  {myClanId === clan.id ? (
                    <span className="text-sm text-green-400 font-medium">Your Clan</span>
                  ) : myClanId ? (
                    <span className="text-sm text-gray-500">Already in a clan</span>
                  ) : clan.member_count >= 25 ? (
                    <span className="text-sm text-red-400">Full</span>
                  ) : (
                    <button
                      onClick={() => handleJoin(clan.id)}
                      className="px-4 py-2 rounded-lg text-sm font-medium bg-[#1a1a1a] border border-[#d4af37]/40 text-[#d4af37] hover:bg-[#d4af37]/10 transition"
                    >
                      Join
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
