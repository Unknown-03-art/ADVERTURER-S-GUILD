"use client";

import { useEffect, useState, useRef } from "react";
import { useRouter } from "next/navigation";
import { supabase, ChatMessage, Profile, RANK_NAMES } from "@/lib/supabase";
import Link from "next/link";
import { containsForbiddenContent, getFilterReason } from "@/lib/word-filter";

export default function PrivateChatPage() {
  const router = useRouter();
  const [profile, setProfile] = useState<Profile | null>(null);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [newMessage, setNewMessage] = useState("");
  const [loading, setLoading] = useState(true);
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const init = async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        router.push("/login");
        return;
      }

      const { data: profileData } = await supabase
        .from("profiles")
        .select("*")
        .eq("id", user.id)
        .single();

      if (!profileData || profileData.rank > 3) {
        router.push("/dashboard");
        return;
      }

      setProfile(profileData);

      const { data: msgs } = await supabase
        .from("private_chat_messages")
        .select("*")
        .order("created_at", { ascending: true })
        .limit(100);

      setMessages(msgs || []);
      setLoading(false);

      const channel = supabase
        .channel("private-leadership-chat")
        .on(
          "postgres_changes",
          { event: "INSERT", schema: "public", table: "private_chat_messages" },
          (payload) => {
            setMessages((prev) => [...prev, payload.new as ChatMessage]);
          }
        )
        .subscribe();

      return () => {
        supabase.removeChannel(channel);
      };
    };
    init();
  }, [router]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const sendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMessage.trim() || !profile) return;

    if (containsForbiddenContent(newMessage)) {
      alert(getFilterReason(newMessage) || "Message blocked by Guild rules.");
      return;
    }

    const { error } = await supabase.from("private_chat_messages").insert({
      user_id: profile.id,
      in_game_name: profile.in_game_name,
      rank: profile.rank,
      message: newMessage.trim(),
    });

    if (!error) setNewMessage("");
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#0a0a0a] text-gray-400">
        Loading private chat...
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-[#0a0a0a]">
      <header className="border-b border-[#2a2a2a] px-4 py-3 flex items-center justify-between bg-[#0f0f0f]">
        <div>
          <h1 className="text-lg font-bold text-red-400">Leadership Private Chat</h1>
          <p className="text-xs text-gray-500">
            Rank 0–3 only • {profile?.in_game_name} ({RANK_NAMES[profile?.rank ?? 5]})
          </p>
        </div>
        <div className="flex gap-3">
          <Link href="/chat" className="text-sm text-gray-400 hover:text-white">Open Chat</Link>
          <Link href="/dashboard" className="text-sm text-gray-400 hover:text-white">Dashboard</Link>
        </div>
      </header>

      <div className="flex-1 overflow-y-auto px-4 py-4 space-y-3">
        {messages.length === 0 && (
          <p className="text-center text-gray-600 py-10">No messages yet.</p>
        )}
        {messages.map((msg) => (
          <div key={msg.id} className={`flex flex-col ${msg.user_id === profile?.id ? "items-end" : "items-start"}`}>
            <div className={`max-w-[80%] rounded-2xl px-4 py-2 ${msg.user_id === profile?.id ? "bg-red-900/30 border border-red-700/40" : "bg-[#1a1a1a] border border-[#2a2a2a]"}`}>
              <div className="flex items-center gap-2 mb-1">
                <span className="text-xs font-semibold text-red-300">{msg.in_game_name}</span>
                <span className="text-[10px] text-gray-600">{RANK_NAMES[msg.rank]}</span>
              </div>
              <p className="text-sm text-gray-100 whitespace-pre-wrap break-words">{msg.message}</p>
              <p className="text-[10px] text-gray-600 mt-1 text-right">
                {new Date(msg.created_at).toLocaleTimeString()}
              </p>
            </div>
          </div>
        ))}
        <div ref={bottomRef} />
      </div>

      <form onSubmit={sendMessage} className="border-t border-[#2a2a2a] p-4 bg-[#0f0f0f] flex gap-3">
        <input
          type="text"
          value={newMessage}
          onChange={(e) => setNewMessage(e.target.value)}
          placeholder="Private leadership message..."
          maxLength={1000}
          className="flex-1 px-4 py-3 rounded-xl bg-[#0a0a0a] border border-[#333] text-white placeholder-gray-600 focus:outline-none focus:border-red-500"
        />
        <button type="submit" className="px-6 py-3 rounded-xl font-semibold text-white bg-red-800 hover:bg-red-700 transition">
          Send
        </button>
      </form>
    </div>
  );
}
