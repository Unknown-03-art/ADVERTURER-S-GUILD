"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { supabase, Profile } from "@/lib/supabase";
import Link from "next/link";

type Post = {
  id: string;
  user_id: string;
  in_game_name: string;
  game_name: string;
  title: string;
  description: string | null;
  players_needed: number;
  status: string;
  created_at: string;
};

export default function RecruitingPage() {
  const router = useRouter();
  const [profile, setProfile] = useState<Profile | null>(null);
  const [posts, setPosts] = useState<Post[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [message, setMessage] = useState("");

  const [gameName, setGameName] = useState("");
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [playersNeeded, setPlayersNeeded] = useState(1);

  useEffect(() => {
    const load = async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        router.push("/login");
        return;
      }
      const { data: profileData } = await supabase.from("profiles").select("*").eq("id", user.id).single();
      if (!profileData) {
        router.push("/login");
        return;
      }
      setProfile(profileData);

      const { data } = await supabase
        .from("recruiting_posts")
        .select("*")
        .eq("status", "open")
        .order("created_at", { ascending: false });
      setPosts(data || []);
      setLoading(false);
    };
    load();
  }, [router]);

  const handleCreate = async () => {
    if (!profile || !gameName.trim() || !title.trim()) {
      setMessage("Game name and title are required.");
      return;
    }

    const { error } = await supabase.from("recruiting_posts").insert({
      user_id: profile.id,
      in_game_name: profile.in_game_name,
      game_name: gameName.trim(),
      title: title.trim(),
      description: description.trim() || null,
      players_needed: playersNeeded,
    });

    if (error) {
      setMessage("Failed to create post.");
      return;
    }

    setMessage("Recruiting post created!");
    setShowForm(false);
    setGameName("");
    setTitle("");
    setDescription("");
    setPlayersNeeded(1);

    const { data } = await supabase
      .from("recruiting_posts")
      .select("*")
      .eq("status", "open")
      .order("created_at", { ascending: false });
    setPosts(data || []);
  };

  const handleClose = async (id: string) => {
    await supabase.from("recruiting_posts").update({ status: "closed" }).eq("id", id);
    setPosts((prev) => prev.filter((p) => p.id !== id));
  };

  if (loading) {
    return <div className="min-h-screen flex items-center justify-center bg-[#0a0a0a] text-gray-400">Loading...</div>;
  }

  return (
    <div className="min-h-screen bg-[#0a0a0a] text-gray-100 px-4 py-8">
      <div className="max-w-3xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <h1 className="text-2xl font-bold text-[#d4af37]">Looking for Players</h1>
          <Link href="/dashboard" className="text-sm text-gray-400 hover:text-white">Dashboard</Link>
        </div>

        {message && (
          <div className="mb-6 p-4 rounded-lg bg-[#1a1a1a] border border-[#d4af37]/30 text-sm text-[#d4af37]">{message}</div>
        )}

        {!showForm ? (
          <button
            onClick={() => setShowForm(true)}
            className="mb-8 px-6 py-3 rounded-lg font-semibold text-black bg-gradient-to-r from-[#d4af37] to-[#b8960c]"
          >
            Post a Recruiting Message
          </button>
        ) : (
          <div className="mb-8 bg-[#141414] border border-[#2a2a2a] rounded-xl p-6 space-y-4">
            <h2 className="text-lg font-semibold text-white">New Recruiting Post</h2>
            <input
              type="text"
              value={gameName}
              onChange={(e) => setGameName(e.target.value)}
              placeholder="Game name"
              className="w-full px-4 py-3 rounded-lg bg-[#0a0a0a] border border-[#333] text-white focus:outline-none focus:border-[#d4af37]"
            />
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Title (e.g. Need 2 supports for ranked)"
              className="w-full px-4 py-3 rounded-lg bg-[#0a0a0a] border border-[#333] text-white focus:outline-none focus:border-[#d4af37]"
            />
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="More details (optional)"
              rows={3}
              className="w-full px-4 py-3 rounded-lg bg-[#0a0a0a] border border-[#333] text-white focus:outline-none focus:border-[#d4af37]"
            />
            <div>
              <label className="block text-sm text-gray-300 mb-1">Players needed</label>
              <input
                type="number"
                min="1"
                max="20"
                value={playersNeeded}
                onChange={(e) => setPlayersNeeded(parseInt(e.target.value) || 1)}
                className="w-24 px-4 py-2 rounded-lg bg-[#0a0a0a] border border-[#333] text-white"
              />
            </div>
            <div className="flex gap-3">
              <button onClick={handleCreate} className="px-5 py-2.5 rounded-lg font-medium text-black bg-gradient-to-r from-[#d4af37] to-[#b8960c]">
                Post
              </button>
              <button onClick={() => setShowForm(false)} className="px-5 py-2.5 rounded-lg text-gray-400 border border-[#333]">
                Cancel
              </button>
            </div>
          </div>
        )}

        <h2 className="text-lg font-semibold text-white mb-4">Open Posts</h2>
        {posts.length === 0 ? (
          <p className="text-gray-500">No open recruiting posts right now.</p>
        ) : (
          <div className="space-y-3">
            {posts.map((post) => (
              <div key={post.id} className="bg-[#141414] border border-[#2a2a2a] rounded-xl p-5">
                <div className="flex justify-between items-start gap-4">
                  <div>
                    <h3 className="font-semibold text-white text-lg">{post.title}</h3>
                    <p className="text-sm text-[#d4af37] mt-1">{post.game_name}</p>
                    <p className="text-sm text-gray-400 mt-1">
                      by {post.in_game_name} • Need {post.players_needed} player{post.players_needed > 1 ? "s" : ""}
                    </p>
                    {post.description && <p className="text-sm text-gray-500 mt-2">{post.description}</p>}
                  </div>
                  {post.user_id === profile?.id && (
                    <button
                      onClick={() => handleClose(post.id)}
                      className="text-xs text-red-400 hover:text-red-300 border border-red-900 px-3 py-1 rounded"
                    >
                      Close
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
