"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { supabase, Profile, RANK_NAMES } from "@/lib/supabase";
import Link from "next/link";

export default function MembersPage() {
  const router = useRouter();
  const [profile, setProfile] = useState<Profile | null>(null);
  const [members, setMembers] = useState<Profile[]>([]);
  const [loading, setLoading] = useState(true);
  const [message, setMessage] = useState("");
  const [actionLoading, setActionLoading] = useState<string | null>(null);

  useEffect(() => {
    const load = async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        router.push("/login");
        return;
      }
      const { data: myProfile } = await supabase.from("profiles").select("*").eq("id", user.id).single();
      if (!myProfile || myProfile.rank > 4) {
        // Only Rank 0-4 can access this page
        router.push("/dashboard");
        return;
      }
      setProfile(myProfile);

      const { data } = await supabase
        .from("profiles")
        .select("*")
        .order("rank", { ascending: true });
      setMembers(data || []);
      setLoading(false);
    };
    load();
  }, [router]);

  const canManage = (target: Profile) => {
    if (!profile) return false;
    // Guild Master can manage everyone except himself
    if (profile.rank === 0 && target.id !== profile.id) return true;
    // Elders & General Commanders can manage lower ranks
    if (profile.rank <= 2 && target.rank > profile.rank) return true;
    // Officers can only issue warnings (handled separately)
    return false;
  };

  const canWarn = (target: Profile) => {
    if (!profile) return false;
    return profile.rank <= 4 && target.rank > profile.rank && target.id !== profile.id;
  };

  const handleRankChange = async (target: Profile, newRank: number) => {
    if (!profile || !canManage(target)) return;
    setActionLoading(target.id);

    const { error } = await supabase
      .from("profiles")
      .update({ rank: newRank, updated_at: new Date().toISOString() })
      .eq("id", target.id);

    if (!error) {
      await supabase.from("rank_changes").insert({
        user_id: target.id,
        changed_by: profile.id,
        old_rank: target.rank,
        new_rank: newRank,
      });
      setMembers((prev) =>
        prev.map((m) => (m.id === target.id ? { ...m, rank: newRank } : m))
      );
      setMessage(`${target.in_game_name} is now Rank ${newRank} (${RANK_NAMES[newRank]})`);
    } else {
      setMessage("Failed to change rank.");
    }
    setActionLoading(null);
  };

  const handleKick = async (target: Profile) => {
    if (!profile || !canManage(target)) return;
    if (!confirm(`Kick ${target.in_game_name} from the guild? This cannot be easily undone.`)) return;

    setActionLoading(target.id);
    // For simplicity we just set a very high rank or you can delete the auth user later
    // Here we set rank to 5 and add a note – full kick would require service role
    const { error } = await supabase
      .from("profiles")
      .update({ rank: 5, bio: (target.bio || "") + " [KICKED]", updated_at: new Date().toISOString() })
      .eq("id", target.id);

    if (!error) {
      setMessage(`${target.in_game_name} has been kicked (rank reset).`);
      setMembers((prev) =>
        prev.map((m) => (m.id === target.id ? { ...m, rank: 5 } : m))
      );
    }
    setActionLoading(null);
  };

  const handleWarn = async (target: Profile) => {
    if (!profile || !canWarn(target)) return;
    const reason = prompt(`Reason for warning ${target.in_game_name}:`);
    if (!reason) return;

    setActionLoading(target.id);

    // Insert warning
    await supabase.from("warnings").insert({
      user_id: target.id,
      issued_by: profile.id,
      reason,
    });

    // Increment warnings count
    const newWarnings = (target.warnings || 0) + 1;
    await supabase
      .from("profiles")
      .update({ warnings: newWarnings })
      .eq("id", target.id);

    setMembers((prev) =>
      prev.map((m) => (m.id === target.id ? { ...m, warnings: newWarnings } : m))
    );

    if (newWarnings >= 3) {
      setMessage(`${target.in_game_name} now has 3 warnings. Report to higher ranks.`);
    } else {
      setMessage(`Warning issued to ${target.in_game_name} (${newWarnings}/3)`);
    }
    setActionLoading(null);
  };

  if (loading) {
    return <div className="min-h-screen flex items-center justify-center bg-[#0a0a0a] text-gray-400">Loading members...</div>;
  }

  return (
    <div className="min-h-screen bg-[#0a0a0a] text-gray-100 px-4 py-8">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-2xl font-bold text-[#d4af37]">Members Management</h1>
            <p className="text-sm text-gray-400">
              Logged in as {profile?.in_game_name} ({RANK_NAMES[profile?.rank ?? 5]})
            </p>
          </div>
          <Link href="/dashboard" className="text-sm text-gray-400 hover:text-white">Dashboard</Link>
        </div>

        {message && (
          <div className="mb-6 p-4 rounded-lg bg-[#1a1a1a] border border-[#d4af37]/30 text-sm text-[#d4af37]">{message}</div>
        )}

        <div className="space-y-3">
          {members.map((m) => (
            <div key={m.id} className="bg-[#141414] border border-[#2a2a2a] rounded-xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <div className="flex items-center gap-2">
                  <span className="font-semibold text-white">{m.in_game_name}</span>
                  <span className="text-xs px-2 py-0.5 rounded bg-[#d4af37]/15 text-[#d4af37]">
                    Rank {m.rank} – {RANK_NAMES[m.rank]}
                  </span>
                  {(m.warnings || 0) > 0 && (
                    <span className="text-xs px-2 py-0.5 rounded bg-red-900/40 text-red-400">
                      {m.warnings} warning{m.warnings > 1 ? "s" : ""}
                    </span>
                  )}
                </div>
                <p className="text-xs text-gray-500">{m.email}</p>
              </div>

              <div className="flex flex-wrap gap-2">
                {canManage(m) && (
                  <>
                    {m.rank > 0 && (
                      <button
                        onClick={() => handleRankChange(m, m.rank - 1)}
                        disabled={actionLoading === m.id}
                        className="text-xs px-3 py-1.5 rounded bg-green-900/50 text-green-300 hover:bg-green-800"
                      >
                        Promote
                      </button>
                    )}
                    {m.rank < 5 && (
                      <button
                        onClick={() => handleRankChange(m, m.rank + 1)}
                        disabled={actionLoading === m.id}
                        className="text-xs px-3 py-1.5 rounded bg-yellow-900/50 text-yellow-300 hover:bg-yellow-800"
                      >
                        Demote
                      </button>
                    )}
                    <button
                      onClick={() => handleKick(m)}
                      disabled={actionLoading === m.id}
                      className="text-xs px-3 py-1.5 rounded bg-red-900/50 text-red-300 hover:bg-red-800"
                    >
                      Kick
                    </button>
                  </>
                )}
                {canWarn(m) && (
                  <button
                    onClick={() => handleWarn(m)}
                    disabled={actionLoading === m.id}
                    className="text-xs px-3 py-1.5 rounded bg-orange-900/50 text-orange-300 hover:bg-orange-800"
                  >
                    Warn
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
