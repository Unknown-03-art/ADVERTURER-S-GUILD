"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { supabase, Profile, RANK_NAMES } from "@/lib/supabase";
import Link from "next/link";

export default function ProfilePage() {
  const router = useRouter();
  const [profile, setProfile] = useState<Profile | null>(null);
  const [bio, setBio] = useState("");
  const [loading, setLoading] = useState(true);
  const [message, setMessage] = useState("");
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    const load = async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        router.push("/login");
        return;
      }
      const { data } = await supabase.from("profiles").select("*").eq("id", user.id).single();
      if (!data) {
        router.push("/login");
        return;
      }
      setProfile(data);
      setBio(data.bio || "");
      setLoading(false);
    };
    load();
  }, [router]);

  const handleSave = async () => {
    if (!profile) return;
    setSaving(true);
    const { error } = await supabase
      .from("profiles")
      .update({ bio: bio.trim() || null, updated_at: new Date().toISOString() })
      .eq("id", profile.id);

    if (error) {
      setMessage("Failed to save.");
    } else {
      setMessage("Profile updated!");
      setProfile({ ...profile, bio: bio.trim() || null });
    }
    setSaving(false);
  };

  if (loading) {
    return <div className="min-h-screen flex items-center justify-center bg-[#0a0a0a] text-gray-400">Loading profile...</div>;
  }

  const frameClass =
    profile?.frame === "gold"
      ? "border-yellow-500 text-yellow-400"
      : profile?.frame === "mystic" || profile?.frame === "legendary" || profile?.frame === "unique"
      ? "border-purple-500 text-purple-300"
      : profile?.frame === "commander"
      ? "border-red-500 text-red-300"
      : "border-[#d4af37] text-[#d4af37]";

  return (
    <div className="min-h-screen bg-[#0a0a0a] text-gray-100 px-4 py-8">
      <div className="max-w-xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <h1 className="text-2xl font-bold text-[#d4af37]">My Profile</h1>
          <Link href="/dashboard" className="text-sm text-gray-400 hover:text-white">Dashboard</Link>
        </div>

        {message && (
          <div className="mb-6 p-4 rounded-lg bg-[#1a1a1a] border border-[#d4af37]/30 text-sm text-[#d4af37]">{message}</div>
        )}

        <div className="bg-[#141414] border border-[#2a2a2a] rounded-2xl p-6 mb-6">
          <div className="flex items-center gap-5 mb-6">
            <div className={`w-20 h-20 rounded-full bg-[#0a0a0a] border-4 flex items-center justify-center text-3xl font-bold ${frameClass}`}>
              AG
            </div>
            <div>
              <h2 className="text-2xl font-bold text-white">{profile?.in_game_name}</h2>
              <p className="text-[#d4af37]">{RANK_NAMES[profile?.rank ?? 5]} (Rank {profile?.rank})</p>
              <p className="text-xs text-gray-500 mt-1">Frame: {profile?.frame || "default"}</p>
            </div>
          </div>

          <div className="space-y-4">
            <div>
              <label className="block text-sm text-gray-300 mb-1">Bio</label>
              <textarea
                value={bio}
                onChange={(e) => setBio(e.target.value)}
                rows={4}
                placeholder="Tell the guild a bit about yourself..."
                className="w-full px-4 py-3 rounded-lg bg-[#0a0a0a] border border-[#333] text-white focus:outline-none focus:border-[#d4af37]"
              />
            </div>

            <button
              onClick={handleSave}
              disabled={saving}
              className="px-6 py-2.5 rounded-lg font-semibold text-black bg-gradient-to-r from-[#d4af37] to-[#b8960c] disabled:opacity-60"
            >
              {saving ? "Saving..." : "Save Profile"}
            </button>
          </div>
        </div>

        <p className="text-xs text-gray-600 text-center">
          Want a special frame? Visit the <Link href="/shop" className="text-[#d4af37] hover:underline">Guild Shop</Link>.
        </p>
      </div>
    </div>
  );
}
